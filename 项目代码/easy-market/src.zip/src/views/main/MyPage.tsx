import React from 'react'

let TopicDetailPage: React.FC = props=>{
    return <>我的</>;
}

export default TopicDetailPage;