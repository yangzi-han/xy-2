import React from 'react'

let TopicDetailPage: React.FC = props=>{
    return null;
}

export default TopicDetailPage;