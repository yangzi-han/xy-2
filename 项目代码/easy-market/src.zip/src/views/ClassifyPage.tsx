import React from 'react'

let TopicDetailPage: React.FC = props=>{
    return <>分类</>;
}

export default TopicDetailPage;